package com.example.flightreservation.controller;

import com.example.flightreservation.entity.Airline;
import com.example.flightreservation.requestDTO.AirlineDTO;
import com.example.flightreservation.responseDTO.AirlineResponse;
import com.example.flightreservation.service.IAirlineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/airline-api")
public class AirlineController {
    @Autowired
    private IAirlineService airlineService;
        @PostMapping("/register")
        public ResponseEntity<String> registerAirline(@RequestBody AirlineDTO airlineDTO)
        {
            String message = airlineService.registerAirline(airlineDTO);
            ResponseEntity<String> responseEntity = new ResponseEntity<>(message, HttpStatus.CREATED);
            return responseEntity;
        }
        @GetMapping("/get-byId/{id}")
        public ResponseEntity<AirlineResponse> getAirlineById(@PathVariable int id)
        {
            AirlineResponse airlineResponse = airlineService.getAirlineById(id);
            ResponseEntity<AirlineResponse> responseEntity = new ResponseEntity<>(airlineResponse, HttpStatus.FOUND);
            return responseEntity;
        }

        @PutMapping("/update")
        public ResponseEntity<String> updateAirline(@RequestParam("id") int id , @RequestBody AirlineDTO airlineDTO)
        {
            String message = airlineService.updateAirline(id,airlineDTO);
            ResponseEntity<String> responseEntity = new ResponseEntity<>(message,HttpStatus.OK);
            return responseEntity;
        }
    }