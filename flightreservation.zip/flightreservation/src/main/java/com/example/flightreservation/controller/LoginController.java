package com.example.flightreservation.controller;

import com.example.flightreservation.entity.Customer;
import com.example.flightreservation.entity.Login;
import com.example.flightreservation.service.ICustomerService;
import com.example.flightreservation.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/login-api")
public class LoginController {
    @Autowired
    private ICustomerService loginService;
    @PostMapping("/authenticate")
    @ResponseBody
    public ResponseEntity<String> authenticate(@RequestBody Customer customer) {
        boolean isAuthenticated = loginService.performLogin(customer.getEmail(), customer.getPassword());
        if (isAuthenticated) {
            loginService.saveCustomer(customer);
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }
}
