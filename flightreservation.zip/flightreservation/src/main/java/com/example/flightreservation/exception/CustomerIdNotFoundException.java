package com.example.flightreservation.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
@Data
public class CustomerIdNotFoundException extends RuntimeException{
    String msg;
    public CustomerIdNotFoundException(String message)
    {
        super(message);
        this.msg=message;
    }
}
