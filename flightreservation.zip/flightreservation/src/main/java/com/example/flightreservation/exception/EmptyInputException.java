package com.example.flightreservation.exception;

public class EmptyInputException extends RuntimeException{

    public EmptyInputException(String message)
    {
        super(message);
    }
}
