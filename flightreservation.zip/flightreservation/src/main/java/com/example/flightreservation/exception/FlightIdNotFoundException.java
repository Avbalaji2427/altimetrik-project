package com.example.flightreservation.exception;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.Data;
@Data
public class FlightIdNotFoundException extends RuntimeException{
        String msg;
        public FlightIdNotFoundException(String message)
        {
            super(message);
            this.msg=message;
        }
    }