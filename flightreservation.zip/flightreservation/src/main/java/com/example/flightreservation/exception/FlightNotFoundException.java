package com.example.flightreservation.exception;

import lombok.Data;
import lombok.AllArgsConstructor;
@Data
public class FlightNotFoundException extends RuntimeException{
        String msg;
        public FlightNotFoundException(String message)
        {
            super(message);
            this.msg=message;
        }
    }
