package com.example.flightreservation.requestDTO;

import java.sql.Date;

public class FlightRequest {

    private int totalSeats;

    private String source;

    private String destination;

    private String departureTime;

    private int fare;

    private int availableSeats;

    private Date departureDate;

    private String airlineName;


    public FlightRequest()
    {

    }

    public String getAirlineName() {
        return airlineName;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public int getFare() {
        return fare;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public Date getDepartureDate() {
        return departureDate;
    }

}
