package com.example.flightreservation.service;

import com.example.flightreservation.entity.Airline;
import com.example.flightreservation.repository.AirlineRepository;
import com.example.flightreservation.requestDTO.AirlineDTO;
import com.example.flightreservation.responseDTO.AirlineResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Service
public class AirlineService implements IAirlineService {
    @Autowired
    private AirlineRepository airlineRepository;

        public String registerAirline(AirlineDTO airlineDTO)
        {
            Airline airline = new Airline(airlineDTO.getAirlineName(),airlineDTO.getDateOfOperation());
            airlineRepository.save(airline);
            return "Airline Added Successfully";
        }

        public AirlineResponse getAirlineById(int id)
        {
            Airline airline = airlineRepository.findById(id).get();
            AirlineResponse airlineRespose = new AirlineResponse(airline.getName(),airline.getDateOfOperation());
            return airlineRespose;
        }

        public String updateAirline(int id, AirlineDTO airlineDTO) {

            Airline airline = airlineRepository.findById(id).get();
            airline.setName(airlineDTO.getAirlineName());
            airline.setDateOfOperation(airlineDTO.getDateOfOperation());
            airlineRepository.save(airline);
            return "Airline details were updated";
        }
    }



