package com.example.flightreservation.service;

import com.example.flightreservation.entity.Customer;
import com.example.flightreservation.repository.CustomerRepository;
import com.example.flightreservation.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomerService implements ICustomerService {
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private LoginRepository loginRepository;

    public boolean registerCustomer(Customer customer) {
        customerRepository.save(customer);
        return true;
    }

    public boolean performLogin(String email, String password) {
        Optional<Customer> customer = customerRepository.findByEmail(email);
        return customer.map(l -> l.getPassword().equals(password)).orElse(false);
    }

    @Override
    public boolean saveCustomer(Customer customer) {
        try {
            loginRepository.save(customer);
            return true;
        }
        catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
