package com.example.flightreservation.service;
import com.example.flightreservation.entity.Airline;
import com.example.flightreservation.entity.Flight;
import com.example.flightreservation.entity.Location;
import com.example.flightreservation.exception.EmptyInputException;
import com.example.flightreservation.repository.AirlineRepository;
import com.example.flightreservation.repository.FlightRepository;
import com.example.flightreservation.requestDTO.FlightRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

@Service
public class FlightService implements IFlightService
{
    @Autowired
    private FlightRepository flightRepository;

    @Autowired
    private AirlineRepository airlineRepository;

    @Override
    public List<Flight> searchAvailableFlights(Location source, Location destination, Date date) {
        return null;
    }
    public String flightRegistration(FlightRequest flightRequest) {
        Flight flight = null;

        Optional<Airline> airline = airlineRepository.findByName(flightRequest.getAirlineName());

        if(airline.isEmpty())
        {
           // throw EmptyInputException;
        }
        else {
            flight = new Flight(flightRequest.getTotalSeats(), flightRequest.getSource(), flightRequest.getDestination(), flightRequest.getDepartureTime(), flightRequest.getFare(), flightRequest.getAvailableSeats(), flightRequest.getDepartureDate() ,airline.get());
        }

        airline.get().addFlight(flight);

        airlineRepository.save(airline.get());
        return "Flight Details saved successfully";
    }

    public List<Flight> searchBySourceAndDestinationAndDepartureDate(String source , String destination , Date date)
    {
        List<Flight> list = flightRepository.findBySourceAndDestinationAndDepartureDate(source,destination,date);
        return list;
    }

    public Optional<Flight> getFlightById(int id) {

        Optional<Flight> flight = flightRepository.findById(id);
        return flight;
    }
}