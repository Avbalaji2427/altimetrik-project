package com.example.flightreservation.service;

import com.example.flightreservation.entity.Airline;
import com.example.flightreservation.requestDTO.AirlineDTO;
import com.example.flightreservation.responseDTO.AirlineResponse;

import java.util.List;

public interface IAirlineService {
    public String updateAirline(int id, AirlineDTO airlineDTO);
    public AirlineResponse getAirlineById(int id);
    public String registerAirline(AirlineDTO airlineDTO);
}
