package com.example.flightreservation.service;

import com.example.flightreservation.entity.Booking;
import com.example.flightreservation.entity.CancelTicket;

public interface ICancelTicketService {
    public CancelTicket cancelBooking(Booking booking);
}
