package com.example.flightreservation.service;

import com.example.flightreservation.entity.Flight;
import com.example.flightreservation.entity.Location;
import com.example.flightreservation.exception.EmptyInputException;
import com.example.flightreservation.exception.FlightIdNotFoundException;
import com.example.flightreservation.exception.FlightNotFoundException;
import com.example.flightreservation.requestDTO.FlightRequest;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

public interface IFlightService{
    public List<Flight> searchAvailableFlights(Location source, Location destination, Date date);

    String flightRegistration(FlightRequest flightRequest);

    List<Flight> searchBySourceAndDestinationAndDepartureDate(String source, String destination, Date date) throws FlightNotFoundException;

    Optional<Flight> getFlightById(int id) throws FlightIdNotFoundException;
}
