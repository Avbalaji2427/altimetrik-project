package com.example.flightreservation.service;

import com.example.flightreservation.entity.Location;

import java.util.List;

public interface ILocationService {
    public List<Location> getAllLocations();
}
