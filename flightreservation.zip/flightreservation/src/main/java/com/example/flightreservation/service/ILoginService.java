package com.example.flightreservation.service;

import com.example.flightreservation.entity.Customer;

public interface ILoginService {
    public boolean performLogin(String email, String password);
}
