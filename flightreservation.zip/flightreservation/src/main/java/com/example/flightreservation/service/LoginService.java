package com.example.flightreservation.service;

import com.example.flightreservation.entity.Customer;
import com.example.flightreservation.entity.Login;
import com.example.flightreservation.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LoginService implements ILoginService {
    @Autowired
    private LoginRepository loginRepository;
    public boolean performLogin(String email, String password) {
        Optional<Login> login = loginRepository.findByEmail(email);
        return login.map(l -> l.getPassword().equals(password)).orElse(false);
    }
}
